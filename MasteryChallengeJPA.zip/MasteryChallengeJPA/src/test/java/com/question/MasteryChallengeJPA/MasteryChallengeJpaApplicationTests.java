package com.question.MasteryChallengeJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MasteryChallengeJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}

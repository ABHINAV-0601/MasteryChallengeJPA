package com.question.MasteryChallengeJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MasteryChallengeJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MasteryChallengeJpaApplication.class, args);
	}

}
